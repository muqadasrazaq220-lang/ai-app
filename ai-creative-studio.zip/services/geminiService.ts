import { GoogleGenAI, Modality } from "@google/genai";
import { Base64Image } from '../types';

const getAI = () => {
    // ALWAYS create a new instance to use the latest API key selected by the user.
    // This resolves an issue where a stale client with an old key was being used.
    // FIX: The API key must be obtained from process.env.API_KEY.
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateImageFromText = async (prompt: string, aspectRatio: '1:1' | '16:9' | '9:16'): Promise<string> => {
    const ai = getAI();
    const enhancedPrompt = `${prompt}, ultra-detailed, 8K resolution, cinematic lighting, realistic texture, perfectly balanced colors`;

    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: enhancedPrompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: aspectRatio,
        },
    });

    const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
    return `data:image/jpeg;base64,${base64ImageBytes}`;
};

export const editImage = async (image: Base64Image, prompt: string): Promise<string> => {
    const ai = getAI();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { inlineData: { data: image.data, mimeType: image.mimeType } },
                { text: prompt },
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
        }
    }
    throw new Error('No image generated');
};

export const upscaleImage = async (image: Base64Image): Promise<string> => {
    const ai = getAI();
    const prompt = "Upscale this image to 4K resolution. Significantly enhance sharpness, clarity, and fine texture details. Focus on creating a photorealistic result with no artifacts. The final image should be a higher resolution version of the input, looking crisp and professional.";
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { inlineData: { data: image.data, mimeType: image.mimeType } },
                { text: prompt },
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            return `data:${part.inlineData.mimeType};base64,${base64ImageBytes}`;
        }
    }
    throw new Error('No image generated');
};

export const enhancePrompt = async (prompt: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: `Enhance the following user prompt to be more descriptive, evocative, and optimized for an AI image generator. Add details about style, lighting, composition, and mood. User prompt: "${prompt}"`,
    config: {
      systemInstruction: "You are a creative assistant who excels at prompt engineering for text-to-image AI models."
    }
  });
  return response.text;
};

export const generateCaption = async (image: Base64Image): Promise<string> => {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { data: image.data, mimeType: image.mimeType } },
          { text: "Generate three social media captions for this image: one creative, one emotional, and one funny. Include relevant hashtags for each. Format the output with clear headings for each style (e.g., **Creative:**, **Emotional:**, **Funny:**)." },
        ],
      },
    });
    return response.text;
}
// FIX: Added generateVideoFromText function to support the TextToVideo component.
export const generateVideoFromText = async (prompt: string, onProgress: (message: string) => void): Promise<string> => {
    const ai = getAI();
    onProgress('Starting video generation...');
    let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
        }
    });

    onProgress('Processing your video... this can take a few minutes.');
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        onProgress('Still processing...');
        operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation completed, but no download link was found.");
    }

    onProgress('Fetching video...');
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    if (!response.ok) {
        throw new Error(`Failed to download video: ${response.statusText}`);
    }
    const videoBlob = await response.blob();
    return URL.createObjectURL(videoBlob);
};

// FIX: Added generateVideoFromImage function to support the ImageToVideo component.
export const generateVideoFromImage = async (image: Base64Image, prompt: string, onProgress: (message: string) => void): Promise<string> => {
    const ai = getAI();
    onProgress('Starting video generation...');
    let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        image: {
            imageBytes: image.data,
            mimeType: image.mimeType,
        },
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
        }
    });

    onProgress('Processing your video... this can take a few minutes.');
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        onProgress('Still processing...');
        operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) {
        throw new Error("Video generation completed, but no download link was found.");
    }

    onProgress('Fetching video...');
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    if (!response.ok) {
        throw new Error(`Failed to download video: ${response.statusText}`);
    }
    const videoBlob = await response.blob();
    return URL.createObjectURL(videoBlob);
};