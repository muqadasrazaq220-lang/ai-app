import React from 'react';

interface ApiKeyPromptProps {
    onSelectKey: () => void;
}

const ApiKeyPrompt: React.FC<ApiKeyPromptProps> = ({ onSelectKey }) => {
    return (
        <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(168,85,247,0.4)] max-w-2xl mx-auto text-center border border-purple-800/50">
            <h2 className="text-2xl font-semibold mb-4 text-purple-300">API Key Required</h2>
            <p className="text-gray-300 mb-6">
                To use the AI creation tools, you need to select a Gemini API key. 
                This key will be used for all generation requests.
            </p>
            <a 
                href="https://ai.google.dev/gemini-api/docs/billing" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-400 hover:underline text-sm mb-6 block"
            >
                Learn more about API keys and billing
            </a>
            <button 
                onClick={onSelectKey} 
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
            >
                Select Your API Key
            </button>
        </div>
    );
};

export default ApiKeyPrompt;
