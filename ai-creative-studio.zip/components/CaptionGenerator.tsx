import React, { useState, useMemo } from 'react';
import { generateCaption } from '../services/geminiService';
import { fileToBase64 } from '../utils';
import { Base64Image, Creation, Tab } from '../types';
import Spinner from './common/Spinner';

interface CaptionGeneratorProps {
  onApiKeyError: () => void;
  onSave: (creation: Omit<Creation, 'id' | 'timestamp'>) => void;
}

export default function CaptionGenerator({ onApiKeyError, onSave }: CaptionGeneratorProps) {
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string>('');
  const [captions, setCaptions] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copiedStates, setCopiedStates] = useState<Record<number, boolean>>({});

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setFilePreview(URL.createObjectURL(selectedFile));
      setError('');
      setCaptions('');
    }
  };

  const handleSubmit = async () => {
    if (!file) {
      setError('Please select an image to generate captions for.');
      return;
    }
    setLoading(true);
    setError('');
    setCaptions('');
    try {
      const base64Image: Base64Image = await fileToBase64(file);
      const result = await generateCaption(base64Image);
      setCaptions(result);
    } catch (e: any) {
      console.error(e);
      const errorMessage = e.message?.toLowerCase() || '';
      if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
        setError('Your API Key appears to be invalid. Please select a new one.');
        onApiKeyError();
      } else {
        setError('Failed to generate captions. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const parsedCaptions = useMemo(() => {
    if (!captions) return [];
    const parts = captions.split(/\*\*(.*?):\*\*/g).filter(s => s.trim() !== '');
    const sections: { title: string, text: string }[] = [];
    for (let i = 0; i < parts.length; i += 2) {
      if (parts[i] && parts[i+1]) {
        sections.push({ title: parts[i], text: parts[i+1].trim() });
      }
    }
    return sections;
  }, [captions]);
  
  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedStates({ ...copiedStates, [index]: true });
    setTimeout(() => {
        setCopiedStates(prev => ({...prev, [index]: false}));
    }, 2000);
  };

  return (
    <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-4xl mx-auto border border-purple-900/50">
      <h2 className="text-2xl font-semibold mb-4 text-purple-300">AI Caption Generator</h2>
      <p className="text-gray-400 mb-6">Never run out of words. Upload an image and get instant, creative captions for your social media posts.</p>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">Upload Image</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            disabled={loading}
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"
          />
        </div>
        
        {filePreview && (
          <div className="p-2 border border-dashed border-gray-600 rounded-lg">
            <img src={filePreview} alt="Preview" className="max-w-xs mx-auto rounded-md" />
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={loading || !file}
          className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
        >
          {loading ? <><Spinner className="w-5 h-5 mr-2" /> Generating Captions...</> : 'Generate Captions'}
        </button>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      
      {parsedCaptions.length > 0 && (
        <div className="mt-6 p-4 bg-gray-900 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Generated Captions</h3>
          <div className="space-y-4">
            {parsedCaptions.map((caption, index) => (
              <div key={index} className="bg-gray-800 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-300 mb-2">{caption.title}</h4>
                <p className="text-gray-300 whitespace-pre-wrap mb-3">{caption.text}</p>
                <button 
                  onClick={() => handleCopy(caption.text, index)}
                  className="w-full text-center py-1.5 text-sm bg-gray-700 hover:bg-gray-600 rounded-lg font-medium transition-colors"
                >
                  {copiedStates[index] ? 'Copied!' : 'Copy'}
                </button>
              </div>
            ))}
          </div>
          <button onClick={() => onSave({ tab: Tab.CAPTION_GENERATOR, prompt: "Image caption", imageUrl: filePreview, resultText: captions })} className="mt-4 w-full text-center py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
            Save Captions
          </button>
        </div>
      )}
    </div>
  );
}