import React, { useState } from 'react';
import { editImage } from '../services/geminiService';
import { fileToBase64 } from '../utils';
import { Base64Image, User, Creation, Tab } from '../types';
import Spinner from './common/Spinner';
import Modal from './common/Modal';

const PREMIUM_FILTERS = ["Crystal Glow", "Mystic Flame", "Galactic Dream"];

interface ImageToImageProps {
  user: User;
  onApiKeyError: () => void;
  onSave: (creation: Omit<Creation, 'id' | 'timestamp'>) => void;
}

export default function ImageToImage({ user, onApiKeyError, onSave }: ImageToImageProps) {
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [lastUsedPrompt, setLastUsedPrompt] = useState('');
  const [resultUrl, setResultUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isResultVisible, setIsResultVisible] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && (selectedFile.type === "image/jpeg" || selectedFile.type === "image/png")) {
      setFile(selectedFile);
      setFilePreview(URL.createObjectURL(selectedFile));
      setError('');
      setResultUrl('');
      setIsResultVisible(false);
    } else {
        setError("Please upload a valid JPEG or PNG image.");
    }
  };

  const handleSubmit = async (presetPrompt?: string) => {
    const finalPrompt = presetPrompt || prompt;
    if (!file) {
      setError('Please select an image file.');
      return;
    }
    if (!finalPrompt) {
      setError('Please enter an editing prompt or select a magic tool.');
      return;
    }
    setLoading(true);
    setError('');
    setResultUrl('');
    setIsResultVisible(false);
    setLastUsedPrompt(finalPrompt);
    try {
      const base64Image: Base64Image = await fileToBase64(file);
      const url = await editImage(base64Image, finalPrompt);
      setResultUrl(url);
      setTimeout(() => setIsResultVisible(true), 100);
    } catch (e: any) {
      console.error(e);
      const errorMessage = e.message?.toLowerCase() || '';
      if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
        setError('Your API Key appears to be invalid. Please select a new one.');
        onApiKeyError();
      } else {
        setError('Image editing failed. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-4xl mx-auto border border-purple-900/50">
      <h2 className="text-2xl font-semibold mb-4 text-purple-300">Magic Edit</h2>
      <p className="text-gray-400 mb-6">Upload an image and use our AI tools to magically transform it.</p>
      
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Premium Feature">
        <p>This premium filter is coming soon! Stay tuned for more amazing features.</p>
      </Modal>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">1. Upload Image (PNG/JPEG)</label>
          <input
            type="file"
            accept="image/jpeg,image/png"
            onChange={handleFileChange}
            disabled={loading}
            className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"
          />
        </div>

        {filePreview && (
          <div className="p-2 border border-dashed border-gray-600 rounded-lg">
            <img src={filePreview} alt="Preview" className="max-w-xs mx-auto rounded-md" />
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">2. Magic Tools &amp; Filters</label>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <button onClick={() => handleSubmit("Remove the background, replace with a transparent background")} disabled={loading || !file} className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm disabled:opacity-50">Remove Background</button>
            <button onClick={() => handleSubmit("Replace the background with a beautiful cinematic landscape")} disabled={loading || !file} className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm disabled:opacity-50">Replace Background</button>
            <button onClick={() => handleSubmit("Dramatically enhance the colors and lighting")} disabled={loading || !file} className="p-2 bg-gray-800 hover:bg-gray-700 rounded-lg text-sm disabled:opacity-50">Enhance Colors</button>
             {PREMIUM_FILTERS.map(filter => (
                <button key={filter} onClick={() => setIsModalOpen(true)} disabled={loading || !file} className="p-2 bg-yellow-800/50 hover:bg-yellow-700/50 rounded-lg text-sm disabled:opacity-50 text-yellow-300">
                    {filter} (soon)
                </button>
             ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">3. Or, Describe Your Own Edit</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
            rows={2}
            placeholder="e.g., Change the background to a futuristic city"
            disabled={loading || !file}
          />
        </div>

        <button
          onClick={() => handleSubmit()}
          disabled={loading || !file || !prompt}
          className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
        >
          {loading ? <><Spinner className="w-5 h-5 mr-2" /> Processing...</> : 'Run Custom Edit'}
        </button>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}
      
      {resultUrl && (
        <div className={`mt-6 p-4 bg-gray-900 rounded-lg transition-opacity duration-500 ease-in ${isResultVisible ? 'opacity-100' : 'opacity-0'}`}>
          <h3 className="text-lg font-medium mb-3">Result</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm text-center text-gray-400 mb-2">Original</h4>
              <img src={filePreview} alt="Original" className="w-full rounded-lg" />
            </div>
            <div>
              <h4 className="text-sm text-center text-gray-400 mb-2">Edited</h4>
              <img src={resultUrl} alt="Edited Result" className="w-full rounded-lg" />
            </div>
          </div>
          <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <a href={resultUrl} download="edited-image.png" className="flex-1 text-center py-2 bg-green-600 hover:bg-green-700 rounded-lg font-medium transition-colors">Download</a>
            <button onClick={() => onSave({ tab: Tab.IMAGE_TO_IMAGE, prompt: lastUsedPrompt, imageUrl: filePreview, resultImageUrl: resultUrl })} className="flex-1 text-center py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
                Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}