import React from 'react';

interface ShareButtonsProps {
  shareUrl: string;
}

const ShareButtons: React.FC<ShareButtonsProps> = ({ shareUrl }) => {
  const text = encodeURIComponent("Check out this cool creation from the AI Creative Studio!");

  return (
    <div className="mt-4 pt-4 border-t border-gray-700">
      <h4 className="text-center text-sm font-medium text-gray-400 mb-2">Share On</h4>
      <div className="flex justify-center items-center gap-4">
        <a href={`https://twitter.com/intent/tweet?url=${shareUrl}&text=${text}`} target="_blank" rel="noopener noreferrer" className="p-2 bg-gray-800 hover:bg-blue-500 rounded-full transition-colors">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"></path></svg>
        </a>
        <button onClick={() => alert("Share to Instagram coming soon!")} className="p-2 bg-gray-800 hover:bg-pink-500 rounded-full transition-colors">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"></path></svg>
        </button>
        <button onClick={() => alert("Share to TikTok coming soon!")} className="p-2 bg-gray-800 hover:bg-cyan-400 rounded-full transition-colors">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-2.43.03-4.63-1.1-6.12-3.02-1.5-1.9-1.96-4.39-1.3-6.66.63-2.16 2.5-3.71 4.54-4.24.04-.01.08-.02.12-.03.23-.06.46-.1.69-.14.03-.64.04-1.28.04-1.93.01-2.35 0-4.7-.01-7.04.01-1.21.53-2.37 1.37-3.29 1.05-1.15 2.58-1.74 4.09-1.6z"></path></svg>
        </button>
      </div>
    </div>
  );
};

export default ShareButtons;
