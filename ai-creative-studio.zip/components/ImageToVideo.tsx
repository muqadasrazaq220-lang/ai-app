import React, { useState, useCallback } from 'react';
import { generateVideoFromImage } from '../services/geminiService';
import { fileToBase64 } from '../utils';
import { Base64Image, User } from '../types';
import Spinner from './common/Spinner';
import ShareButtons from './common/ShareButtons';

interface ImageToVideoProps {
  user: User;
  onApiKeyError: () => void;
}

export default function ImageToVideo({ user, onApiKeyError }: ImageToVideoProps) {
    const [file, setFile] = useState<File | null>(null);
    const [filePreview, setFilePreview] = useState<string>('');
    const [prompt, setPrompt] = useState('');
    const [resultUrl, setResultUrl] = useState('');
    const [loading, setLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [error, setError] = useState('');
    const [isResultVisible, setIsResultVisible] = useState(false);
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            setFile(selectedFile);
            setFilePreview(URL.createObjectURL(selectedFile));
            setError('');
            setResultUrl('');
            setIsResultVisible(false);
        }
    };
    
    const handleProgressUpdate = useCallback((message: string) => {
        setLoadingMessage(message);
    }, []);

    const handleSubmit = async () => {
        if (!file) { setError('Please select an image file.'); return; }
        if (!prompt) { setError('Please enter a prompt.'); return; }
        
        setLoading(true);
        setError('');
        setResultUrl('');
        setIsResultVisible(false);
        setLoadingMessage("Preparing your assets...");
        
        try {
            const base64Image: Base64Image = await fileToBase64(file);
            const url = await generateVideoFromImage(base64Image, prompt, handleProgressUpdate);
            setResultUrl(url);
            setTimeout(() => setIsResultVisible(true), 100);
        } catch (e: any) {
            console.error(e);
            const errorMessage = e.message?.toLowerCase() || '';
            if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
                setError('Your API Key may be invalid or lack video permissions. Please select a new one.');
                onApiKeyError();
            } else {
                 setError('Video generation failed. Please try again later.');
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-4xl mx-auto border border-purple-900/50">
            <h2 className="text-2xl font-semibold mb-4 text-purple-300">Image → Video</h2>
            <p className="text-gray-400 mb-6">Bring your static images to life. Upload a starting frame and describe the motion.</p>

            <div className="space-y-6">
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">1. Upload Starting Image</label>
                    <input type="file" accept="image/*" onChange={handleFileChange} disabled={loading} className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700 cursor-pointer"/>
                </div>
                {filePreview && <div className="p-2 border border-dashed border-gray-600 rounded-lg"><img src={filePreview} alt="Preview" className="max-w-xs mx-auto rounded-md"/></div>}
                <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">2. Describe the Motion</label>
                    <textarea value={prompt} onChange={e => setPrompt(e.target.value)} disabled={loading || !file} className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors" rows={3} placeholder="e.g., The robot waves, city lights flicker, rain falls"/>
                </div>
                <button onClick={handleSubmit} disabled={loading || !file || !prompt} className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg">
                    {loading ? <><Spinner className="w-5 h-5 mr-2" /> Creating Video...</> : 'Create Video'}
                </button>
            </div>
            
            {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}

            {loading && (
                <div className="mt-6 text-center text-gray-400">
                    <p className="font-semibold text-lg mb-4">{loadingMessage}</p>
                    <div className="w-full bg-gray-700 rounded-full h-2.5 overflow-hidden">
                        <div style={{width: '100%'}} className="bg-gradient-to-r from-purple-500 to-blue-500 h-2.5 rounded-full animate-[wiggle_2s_ease-in-out_infinite]"></div>
                    </div>
                </div>
            )}
            
            {resultUrl && (
                <div className={`mt-6 p-4 bg-gray-900 rounded-lg transition-opacity duration-500 ease-in ${isResultVisible ? 'opacity-100' : 'opacity-0'}`}>
                    <h3 className="text-lg font-medium mb-3">Generated Video</h3>
                    <video src={resultUrl} controls autoPlay loop className="w-full rounded-lg shadow-xl"></video>
                    <a href={resultUrl} download="generated-video.mp4" className="mt-4 inline-block w-full text-center py-2 bg-green-600 hover:bg-green-700 rounded-lg font-medium transition-colors">Download Video</a>
                    <ShareButtons shareUrl={window.location.href} />
                </div>
            )}
        </div>
    );
}