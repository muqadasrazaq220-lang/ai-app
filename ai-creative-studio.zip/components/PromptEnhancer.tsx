import React, { useState } from 'react';
import { enhancePrompt } from '../services/geminiService';
import Spinner from './common/Spinner';
import { Creation, Tab } from '../types';

interface PromptEnhancerProps {
  onApiKeyError: () => void;
  onSave: (creation: Omit<Creation, 'id' | 'timestamp'>) => void;
}

export default function PromptEnhancer({ onApiKeyError, onSave }: PromptEnhancerProps) {
  const [prompt, setPrompt] = useState('');
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copySuccess, setCopySuccess] = useState(false);

  const handleEnhance = async () => {
    if (!prompt) {
      setError('Please enter a prompt to enhance.');
      return;
    }
    setLoading(true);
    setEnhancedPrompt('');
    setError('');
    setCopySuccess(false);
    try {
      const result = await enhancePrompt(prompt);
      setEnhancedPrompt(result);
    } catch (e: any) {
      console.error(e);
      const errorMessage = e.message?.toLowerCase() || '';
      if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
        setError('Your API Key appears to be invalid. Please select a new one.');
        onApiKeyError();
      } else {
        setError('Failed to enhance prompt. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(enhancedPrompt);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  return (
    <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-4xl mx-auto border border-purple-900/50">
      <h2 className="text-2xl font-semibold mb-4 text-purple-300">Prompt Enhancer</h2>
      <p className="text-gray-400 mb-6">Turn simple ideas into masterful prompts. Write a basic concept and let the AI add the magic details.</p>
      
      <div className="space-y-4">
        <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Your Idea</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
              rows={3}
              placeholder="e.g., a robot cat"
              disabled={loading}
            />
        </div>
        <button
          onClick={handleEnhance}
          disabled={loading || !prompt}
          className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
        >
          {loading ? <><Spinner className="w-5 h-5 mr-2" /> Enhancing...</> : 'Enhance Prompt'}
        </button>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}

      {loading && (
        <div className="mt-6 text-center text-gray-400">
            <p>Consulting with the prompt muse...</p>
        </div>
      )}

      {enhancedPrompt && (
        <div className="mt-6 p-4 bg-gray-900 rounded-lg">
          <h3 className="text-lg font-medium mb-3">Enhanced Prompt</h3>
          <p className="text-gray-300 bg-gray-800 p-4 rounded-md whitespace-pre-wrap">{enhancedPrompt}</p>
          <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <button onClick={handleCopy} className="flex-1 text-center py-2 bg-green-600 hover:bg-green-700 rounded-lg font-medium transition-colors">
                {copySuccess ? 'Copied!' : 'Copy to Clipboard'}
            </button>
            <button onClick={() => onSave({ tab: Tab.PROMPT_ENHANCER, prompt: prompt, resultText: enhancedPrompt })} className="flex-1 text-center py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
                Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}