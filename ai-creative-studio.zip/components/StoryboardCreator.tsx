import React, { useState } from 'react';
import { generateImageFromText } from '../services/geminiService';
import Spinner from './common/Spinner';
import { Creation, Tab } from '../types';

interface StoryboardCreatorProps {
  onApiKeyError: () => void;
  onSave: (creation: Omit<Creation, 'id' | 'timestamp'>) => void;
}

export default function StoryboardCreator({ onApiKeyError, onSave }: StoryboardCreatorProps) {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<string[]>([]);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    if (!prompt) {
      setError('Please enter a prompt for your storyboard.');
      return;
    }
    setLoading(true);
    setResults([]);
    setError('');
    
    try {
      // Generate 4 images in parallel
      const imagePromises = Array(4).fill(null).map((_, i) => 
        generateImageFromText(`${prompt}, cinematic still, panel ${i+1} of 4`, '16:9')
      );
      const imageUrls = await Promise.all(imagePromises);
      setResults(imageUrls);
    } catch (e: any) {
      console.error(e);
      const errorMessage = e.message?.toLowerCase() || '';
      if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
        setError('Your API Key appears to be invalid. Please select a new one.');
        onApiKeyError();
      } else {
        setError('Storyboard generation failed. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-5xl mx-auto border border-purple-900/50">
      <h2 className="text-2xl font-semibold mb-4 text-purple-300">Storyboard Creator</h2>
      <p className="text-gray-400 mb-6">Visualize a sequence of events or ideas. Enter a core theme, and the AI will generate a 4-panel storyboard.</p>
      
      <div className="space-y-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
          rows={3}
          placeholder="e.g., A detective discovering a clue in a rainy futuristic city"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading || !prompt}
          className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
        >
          {loading ? <><Spinner className="w-5 h-5 mr-2" /> Generating Panels...</> : 'Generate Storyboard'}
        </button>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}

      {loading && (
        <div className="mt-6 text-center text-gray-400">
            <p>Directing your cinematic sequence...</p>
        </div>
      )}

      {results.length > 0 && (
        <div className="mt-6 p-4 bg-gray-900 rounded-lg">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-lg font-medium">Your Storyboard</h3>
            <button 
                onClick={() => onSave({ tab: Tab.STORYBOARD_CREATOR, prompt: prompt, storyboardUrls: results })}
                className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors"
            >
              Save Storyboard
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {results.map((url, index) => (
                <div key={index} className="relative group aspect-video bg-gray-800 rounded-lg overflow-hidden">
                    <img src={url} alt={`Storyboard panel ${index + 1}`} className="w-full h-full object-cover"/>
                    <a 
                      href={url} 
                      download={`storyboard-panel-${index+1}.jpeg`}
                      className="absolute bottom-2 right-2 p-2 bg-black/50 hover:bg-black/80 rounded-full transition-all opacity-0 group-hover:opacity-100"
                      title="Download Panel"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </a>
                </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}