import React, { useState, useEffect } from 'react';
import { generateImageFromText } from '../services/geminiService';
import Spinner from './common/Spinner';
import { User, Creation, Tab } from '../types';
import ShareButtons from './common/ShareButtons';

const LOADING_MESSAGES = [
    "Painting your imagination...",
    "Summoning your dream creation...",
    "Translating ideas into pixels...",
    "Crafting a digital masterpiece...",
];

const STYLES = ['Realistic', 'Anime', 'Fantasy', 'Digital Art', '3D Render'];
const ASPECT_RATIOS: { label: string, value: '1:1' | '16:9' | '9:16' }[] = [
    { label: 'Square (1:1)', value: '1:1' },
    { label: 'Widescreen (16:9)', value: '16:9' },
    { label: 'Portrait (9:16)', value: '9:16' },
];

interface TextToImageProps {
  user: User;
  onApiKeyError: () => void;
  onSave: (creation: Omit<Creation, 'id' | 'timestamp'>) => void;
}

export default function TextToImage({ user, onApiKeyError, onSave }: TextToImageProps) {
  const [prompt, setPrompt] = useState('');
  const [lastPrompt, setLastPrompt] = useState('');
  const [style, setStyle] = useState('Realistic');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | '16:9' | '9:16'>('1:1');
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState(LOADING_MESSAGES[0]);
  const [resultUrl, setResultUrl] = useState('');
  const [error, setError] = useState('');
  const [isResultVisible, setIsResultVisible] = useState(false);

  useEffect(() => {
    let interval: ReturnType<typeof setTimeout>;
    if (loading) {
      interval = setInterval(() => {
        setLoadingMessage(prev => {
          const currentIndex = LOADING_MESSAGES.indexOf(prev);
          return LOADING_MESSAGES[(currentIndex + 1) % LOADING_MESSAGES.length];
        });
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleGenerate = async (useLastPrompt = false) => {
    const currentPrompt = useLastPrompt ? lastPrompt : prompt;
    if (!currentPrompt) {
      setError('Please enter a prompt.');
      return;
    }
    setLoading(true);
    setResultUrl('');
    setIsResultVisible(false);
    setError('');
    
    try {
      const fullPrompt = `${currentPrompt}, ${style} style`;
      setLastPrompt(fullPrompt); // Save the full prompt including style
      const url = await generateImageFromText(fullPrompt, aspectRatio);
      setResultUrl(url);
      setTimeout(() => setIsResultVisible(true), 100);
    } catch (e: any) {
      console.error(e);
      const errorMessage = e.message?.toLowerCase() || '';
      if (errorMessage.includes("not found") || errorMessage.includes("api key")) {
        setError('Your API Key appears to be invalid. Please select a new one.');
        onApiKeyError();
      } else {
        setError('Image generation failed. Please try again later.');
      }
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="bg-gray-900/50 p-6 rounded-2xl shadow-[0_0_20px_rgba(128,90,213,0.3)] max-w-4xl mx-auto border border-purple-900/50">
      <h2 className="text-2xl font-semibold mb-4 text-purple-300">Text → Image</h2>
      <p className="text-gray-400 mb-6">Describe your vision and let the AI bring it to life.</p>
      
      <div className="space-y-4">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="w-full p-3 bg-gray-900 border border-gray-700 rounded-lg text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
          rows={3}
          placeholder="e.g., A majestic lion wearing a crown, cinematic lighting"
          disabled={loading}
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Style</label>
                <select value={style} onChange={e => setStyle(e.target.value)} disabled={loading} className="w-full p-2 bg-gray-800 border border-gray-600 rounded-lg">
                    {STYLES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Aspect Ratio</label>
                <select value={aspectRatio} onChange={e => setAspectRatio(e.target.value as any)} disabled={loading} className="w-full p-2 bg-gray-800 border border-gray-600 rounded-lg">
                    {ASPECT_RATIOS.map(ar => <option key={ar.value} value={ar.value}>{ar.label}</option>)}
                </select>
            </div>
        </div>
        <div className="flex flex-wrap gap-4">
            <button
              onClick={() => handleGenerate(false)}
              disabled={loading || !prompt}
              className="flex-1 flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 disabled:from-purple-800/50 disabled:to-blue-800/50 disabled:text-gray-400 disabled:cursor-not-allowed rounded-lg font-semibold text-white transition-all duration-200 shadow-lg"
            >
              {loading ? <><Spinner className="w-5 h-5 mr-2" /> Generating...</> : 'Generate'}
            </button>
            <button
                onClick={() => handleGenerate(true)}
                disabled={loading || !lastPrompt}
                title="Generate a new variation with the same prompt"
                className="px-6 py-3 bg-gray-700 hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 rounded-lg font-semibold"
            >
                Regenerate
            </button>
        </div>
      </div>

      {error && <p className="mt-4 text-red-400 bg-red-900/50 p-3 rounded-lg">{error}</p>}

      {loading && (
        <div className="mt-6 text-center text-gray-400">
            <p className="transition-opacity duration-500">{loadingMessage}</p>
        </div>
      )}

      {resultUrl && (
        <div className={`mt-6 p-4 bg-gray-900 rounded-lg transition-opacity duration-500 ease-in ${isResultVisible ? 'opacity-100' : 'opacity-0'}`}>
          <h3 className="text-lg font-medium mb-3">Your Creation</h3>
          <img src={resultUrl} alt="Generated result" className="w-full max-w-lg mx-auto rounded-lg shadow-xl" />
          <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <a
              href={resultUrl}
              download="generated-image.jpeg"
              className="flex-1 text-center py-2 bg-green-600 hover:bg-green-700 rounded-lg font-medium transition-colors"
            >
              Download
            </a>
            <button onClick={() => onSave({ tab: Tab.TEXT_TO_IMAGE, prompt: lastPrompt, resultImageUrl: resultUrl })} className="flex-1 text-center py-2 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors">
                Save
            </button>
          </div>
          <ShareButtons shareUrl={window.location.href} />
        </div>
      )}
    </div>
  );
}